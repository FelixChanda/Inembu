package dev.lexip.hecate.util.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Binder
import android.os.IBinder
import android.os.Parcel
import android.util.Log
import dev.lexip.hecate.logging.Logger
import rikka.shizuku.Shizuku
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object ShizukuManager {

	private const val TAG = "ShizukuManager"
	private const val REQUEST_CODE = 1001

	@Volatile
	private var binderReady: Boolean = false

	sealed class GrantResult {
		object Success : GrantResult()
		object ServiceNotRunning : GrantResult()
		object NotAuthorized : GrantResult()
		object Unexpected : GrantResult()
		data class ShellCommandFailed(
			val commandIndex: Int,
			val command: String,
			val exitCode: Int
		) : GrantResult()
	}

	init {
		try {
			Shizuku.addBinderReceivedListener { onBinderReceived() }
			Shizuku.addBinderDeadListener { onBinderDead() }
			if (Shizuku.pingBinder()) {
				binderReady = true
			}
		} catch (t: Throwable) {
			Log.w(TAG, "Failed to register Shizuku binder listeners", t)
		}
	}

	private fun onBinderReceived() {
		binderReady = true
	}

	private fun onBinderDead() {
		binderReady = false
	}

	fun isBinderReady(): Boolean = binderReady

	fun hasPermission(context: Context): Boolean {
		if (Shizuku.isPreV11()) return false
		if (!binderReady) return false

		return try {
			Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
		} catch (t: Throwable) {
			Log.w(TAG, "Failed to check Shizuku permission", t)
			Logger.logUnexpectedShizukuError(
				context = context,
				operation = "check_permission",
				stage = "check_self_permission",
				throwable = t,
				binderReady = binderReady
			)
			false
		}
	}

	fun requestPermission() {
		if (Shizuku.isPreV11()) {
			Log.w(TAG, "Ignoring Shizuku.requestPermission on pre-v11")
			return
		}

		if (!binderReady) {
			Log.w(TAG, "Binder not ready, skipping Shizuku.requestPermission")
			return
		}

		if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
			return
		}

		Shizuku.requestPermission(REQUEST_CODE)
	}

	fun buildGrantWriteSecureSettingsCommand(packageName: String): String =
		GrantCommandBuilder.grantWriteSecureSettings(packageName)

	fun buildAllGrantCommands(packageName: String): List<String> =
		GrantCommandBuilder.all(packageName)

	fun executeGrantViaShizuku(context: Context, packageName: String): GrantResult {
		if (Shizuku.isPreV11()) return GrantResult.ServiceNotRunning
		if (!binderReady) return GrantResult.ServiceNotRunning
		if (!hasPermission(context)) return GrantResult.NotAuthorized

		val commands = buildAllGrantCommands(packageName)

		return try {
			val monitor = CountDownLatch(1)
			var result: GrantResult = GrantResult.Unexpected

			val args = createGrantServiceArgs()
			val connection = createGrantServiceConnection(
				context,
				args,
				commands,
				monitor,
				packageName
			) { grantResult ->
				result = grantResult
			}

			Shizuku.bindUserService(args, connection)
			waitForGrantResult(monitor)

			result
		} catch (t: Throwable) {
			Log.e(TAG, "Grant via Shizuku failed", t)
			Logger.logUnexpectedShizukuError(
				context = context,
				operation = "grant_write_secure_settings",
				stage = "execute_grant_via_shizuku",
				throwable = t,
				binderReady = binderReady,
				packageName = packageName
			)
			GrantResult.Unexpected
		}
	}

	private fun createGrantServiceArgs(): Shizuku.UserServiceArgs {
		val component = ComponentName(
			"dev.lexip.hecate",
			GrantService::class.java.name
		)
		return Shizuku.UserServiceArgs(component)
			.processNameSuffix("shizuku_grant")
	}

	private fun createGrantServiceConnection(
		context: Context,
		args: Shizuku.UserServiceArgs,
		commands: List<String>,
		monitor: CountDownLatch,
		packageName: String,
		onResult: (GrantResult) -> Unit
	): ServiceConnection {
		return object : ServiceConnection {
			override fun onServiceConnected(
				name: ComponentName?,
				binder: IBinder?
			) {
				val result = try {
					if (binder == null) {
						GrantResult.ServiceNotRunning
					} else {
						executeGrantTransaction(binder, commands)
					}
				} catch (t: Throwable) {
					when (t) {
						is SecurityException -> GrantResult.NotAuthorized
						else -> {
							Logger.logUnexpectedShizukuError(
								context = context,
								operation = "grant_write_secure_settings",
								stage = "on_service_connected_execute",
								throwable = t,
								binderReady = binderReady,
								packageName = packageName
							)
							GrantResult.Unexpected
						}
					}
				} finally {
					try {
						Shizuku.unbindUserService(args, this, true)
					} catch (t: Throwable) {
						Log.w(TAG, "Error while unbinding Shizuku user service", t)
						Logger.logUnexpectedShizukuError(
							context = context,
							operation = "grant_write_secure_settings",
							stage = "unbind_user_service",
							throwable = t,
							binderReady = binderReady,
							packageName = packageName
						)
					}
					monitor.countDown()
				}

				onResult(result)
			}

			override fun onServiceDisconnected(name: ComponentName?) {
				Log.d(TAG, "GrantService disconnected: $name")
			}
		}
	}

	private fun executeGrantTransaction(
		binder: IBinder,
		commands: List<String>
	): GrantResult {
		val data = Parcel.obtain()
		val reply = Parcel.obtain()
		return try {
			data.writeInterfaceToken("dev.lexip.hecate.util.shizuku.GrantService")
			data.writeInt(commands.size)
			commands.forEach { data.writeString(it) }
			val transactionCode = Binder.FIRST_CALL_TRANSACTION + 1
			val success = binder.transact(transactionCode, data, reply, 0)
			if (!success) {
				GrantResult.ServiceNotRunning
			} else {
				val failedIndex = reply.readInt()
				val exitCode = reply.readInt()
				if (failedIndex == -1 && exitCode == 0) {
					GrantResult.Success
				} else {
					val safeIndex = failedIndex.coerceIn(0, (commands.size - 1).coerceAtLeast(0))
					val cmd: String = if (safeIndex in commands.indices) {
						commands[safeIndex]
					} else {
						"<unknown>"
					}
					GrantResult.ShellCommandFailed(
						commandIndex = failedIndex,
						command = cmd,
						exitCode = exitCode
					)
				}
			}
		} finally {
			data.recycle()
			reply.recycle()
		}
	}

	private fun waitForGrantResult(monitor: CountDownLatch) {
		try {
			monitor.await(5, TimeUnit.SECONDS)
		} catch (t: InterruptedException) {
			Log.w(TAG, "Interrupted while waiting for Shizuku user service", t)
		}
	}
}
